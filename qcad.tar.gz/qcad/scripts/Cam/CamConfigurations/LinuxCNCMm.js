// include LinuxCNC configuration:
include("LinuxCNC.js");

// constructor: set up global settings:
function LinuxCNCMm(documentInterface, newDocumentInterface) {
    LinuxCNC.call(this, documentInterface, newDocumentInterface);

    // output unit is always Millimeter:
    this.unit = RS.Millimeter;

    // output three decimals (e.g. 1.234):
    this.decimals = 3;
}

// configuration is derrived from LinuxCNC:
LinuxCNCMm.prototype = new LinuxCNC();
LinuxCNCMm.displayName = "LinuxCNC (Millimeter)";
