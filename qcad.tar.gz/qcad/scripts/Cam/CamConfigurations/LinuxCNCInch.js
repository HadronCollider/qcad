// include LinuxCNC configuration:
include("LinuxCNC.js");

// constructor: set up global settings:
function LinuxCNCInch(documentInterface, newDocumentInterface) {
    LinuxCNC.call(this, documentInterface, newDocumentInterface);

    // output unit is always inch:
    this.unit = RS.Inch;

    // output four decimals (e.g. 1.2345):
    this.decimals = 4;
}

// configuration is derrived from LinuxCNC:
LinuxCNCInch.prototype = new LinuxCNC();
LinuxCNCInch.displayName = "LinuxCNC (Inch)";
